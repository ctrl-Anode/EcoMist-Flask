#!/usr/bin/env bash

echo "Using pip install instead of Poetry"
pip install -r requirements.txt
